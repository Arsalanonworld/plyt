import React from 'react';
import { Helmet } from 'react-helmet';
import Header from '@/components/plyt/Header';
import Hero from '@/components/plyt/Hero';
import FlavourShowcase from '@/components/plyt/FlavourShowcase';
import WhatsInside from '@/components/plyt/WhatsInside';
import SocialSection from '@/components/plyt/SocialSection';
import Waitlist from '@/components/plyt/Waitlist';
import Footer from '@/components/plyt/Footer';

const HomePage = () => {
    return (
        <div className="min-h-screen bg-bone text-ink">
            <Helmet>
                <title>PLYT — Performance Hydration | Hydration with a Pulse</title>
                <meta
                    name="description"
                    content="PLYT is performance hydration with a pulse — four flavours engineered for the full session. Bright, bold, built for the grinders. Drop 01 is loading — join the early-access waitlist at plyt.in."
                />
            </Helmet>
            <Header />
            <main>
                <Hero />
                <FlavourShowcase />
                <WhatsInside />
                <SocialSection />
                <Waitlist />
            </main>
            <Footer />
        </div>
    );
};

export default HomePage;

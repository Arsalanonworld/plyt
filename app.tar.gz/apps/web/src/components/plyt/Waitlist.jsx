import React, { useState } from 'react';
import pb from '@/lib/pocketbaseClient';
import Reveal from '@/components/Reveal';
import { ArrowRight, Check, Loader2, PartyPopper } from 'lucide-react';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const Waitlist = () => {
    const [email, setEmail] = useState('');
    const [state, setState] = useState('idle'); // idle | submitting | success | duplicate | error
    const [message, setMessage] = useState('');

    const onSubmit = async (e) => {
        e.preventDefault();
        const value = email.trim().toLowerCase();
        if (!EMAIL_RE.test(value)) {
            setState('error');
            setMessage('Enter a valid email address.');
            return;
        }
        setState('submitting');
        setMessage('');
        try {
            await pb.collection('waitlist').create({ email: value });
            setState('success');
            setMessage("You're on the list. Watch your inbox — we'll be in touch before Drop 01 lands.");
        } catch (err) {
            if (err?.status === 400) {
                setState('duplicate');
                setMessage("You're already on the list. Sit tight.");
            } else {
                setState('error');
                setMessage('Something went wrong. Try again in a moment.');
            }
        }
    };

    const done = state === 'success' || state === 'duplicate';

    return (
        <section id="waitlist" className="relative overflow-hidden bg-orange">
            {/* playful accents */}
            <div className="pointer-events-none absolute -left-10 top-10 h-40 w-40 blob-a bg-ink/10" aria-hidden="true" />
            <div className="pointer-events-none absolute -right-12 bottom-16 h-52 w-52 blob-b bg-pink/40" aria-hidden="true" />
            <div className="pointer-events-none absolute right-1/4 top-8 h-24 w-24 blob-c bg-lime/50" aria-hidden="true" />

            <div className="relative mx-auto max-w-3xl px-4 py-24 text-center md:px-6 md:py-36">
                <Reveal>
                    <span className="font-tech inline-flex items-center gap-2 rounded-full border-2 border-ink bg-bone px-4 py-1.5 text-[11px] font-bold tracking-widest text-ink">
                        <PartyPopper className="h-3.5 w-3.5" strokeWidth={2.5} />
                        EARLY ACCESS — DROP 01
                    </span>
                </Reveal>

                <Reveal delay={0.08}>
                    <h2 className="font-display mt-6 text-5xl font-extrabold uppercase leading-[0.9] tracking-tight text-ink sm:text-7xl md:text-8xl">
                        Be first<br />in the room.
                    </h2>
                </Reveal>

                <Reveal delay={0.14}>
                    <p className="mx-auto mt-6 max-w-md text-base leading-relaxed text-ink/80 md:text-lg">
                        Drop your email and you'll hear about Drop 01 before anyone else —
                        early access, first-look drops, and the inside line. No spam, ever.
                    </p>
                </Reveal>

                <Reveal delay={0.2}>
                    {done ? (
                        <div className="sticker mx-auto mt-10 flex max-w-xl items-center gap-4 rounded-3xl bg-bone p-5 text-left">
                            <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-ink text-bone">
                                <Check className="h-6 w-6" strokeWidth={2.5} />
                            </span>
                            <p className="font-tech text-[12px] font-bold leading-relaxed tracking-wide text-ink">
                                {message}
                            </p>
                        </div>
                    ) : (
                        <form onSubmit={onSubmit} className="mx-auto mt-10 max-w-xl" noValidate>
                            <div className="sticker flex flex-col gap-3 rounded-full bg-bone p-2 sm:flex-row sm:items-center">
                                <input
                                    id="waitlist-email"
                                    type="email"
                                    autoComplete="email"
                                    placeholder="you@example.com"
                                    value={email}
                                    onChange={(e) => {
                                        setEmail(e.target.value);
                                        if (state === 'error') {
                                            setState('idle');
                                            setMessage('');
                                        }
                                    }}
                                    className="font-tech h-12 flex-1 rounded-full bg-transparent px-5 text-sm tracking-wide text-ink placeholder:text-ink/35 focus:outline-none"
                                />
                                <button
                                    type="submit"
                                    disabled={state === 'submitting'}
                                    className="font-tech inline-flex h-12 items-center justify-center gap-2 rounded-full bg-ink px-7 text-[12px] font-bold tracking-widest text-bone transition-transform duration-200 hover:-translate-y-0.5 active:scale-95 disabled:cursor-not-allowed disabled:opacity-70"
                                >
                                    {state === 'submitting' ? (
                                        <>
                                            JOINING
                                            <Loader2 className="h-4 w-4 animate-spin" strokeWidth={2} />
                                        </>
                                    ) : (
                                        <>
                                            NOTIFY ME
                                            <ArrowRight className="h-4 w-4" strokeWidth={2.5} />
                                        </>
                                    )}
                                </button>
                            </div>
                            {state === 'error' && message && (
                                <p className="font-tech mt-3 text-[11px] font-bold tracking-widest text-ink">
                                    {message}
                                </p>
                            )}
                        </form>
                    )}
                </Reveal>
            </div>
        </section>
    );
};

export default Waitlist;

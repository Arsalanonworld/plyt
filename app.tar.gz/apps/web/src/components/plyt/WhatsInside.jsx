import React from 'react';
import Reveal from '@/components/Reveal';
import { Zap, Droplets, Leaf, Gauge } from 'lucide-react';

const points = [
    {
        icon: Zap,
        color: 'bg-orange',
        title: 'Functional electrolytes',
        body: 'A mix that actually does the job — sodium, potassium, magnesium working together so you can keep going.',
    },
    {
        icon: Droplets,
        color: 'bg-pink',
        title: 'No sugar bombs',
        body: 'No syrupy sweetness, no crash. Clean flavour engineered to drink fast and drink often.',
    },
    {
        icon: Leaf,
        color: 'bg-lime',
        title: 'Made to go long',
        body: 'Built for the full session — the long sets, the extra overs, the last sprint when your legs are empty.',
    },
    {
        icon: Gauge,
        color: 'bg-purple',
        title: 'No noise',
        body: 'No athlete-and-sweat clichés. Just bold type, strange colour, and a mix that works.',
    },
];

const WhatsInside = () => {
    return (
        <section className="relative overflow-hidden bg-ink text-bone">
            <div className="pointer-events-none absolute -right-20 -top-20 h-72 w-72 blob-a bg-purple/40" aria-hidden="true" />
            <div className="pointer-events-none absolute -left-16 bottom-10 h-56 w-56 blob-b bg-orange/30" aria-hidden="true" />

            <div className="relative mx-auto max-w-6xl px-4 py-20 md:px-6 md:py-32">
                <div className="grid grid-cols-1 gap-12 md:grid-cols-12 md:gap-8">
                    <div className="md:col-span-5">
                        <Reveal>
                            <p className="font-tech mb-4 text-[11px] font-bold tracking-widest text-orange">
                                / WHAT'S INSIDE
                            </p>
                        </Reveal>
                        <Reveal delay={0.08}>
                            <h2 className="font-display text-4xl font-extrabold uppercase leading-[0.95] tracking-tight text-bone sm:text-5xl md:text-6xl">
                                Water is the warm-up.{' '}
                                <span className="text-lime">PLYT is the work.</span>
                            </h2>
                        </Reveal>
                        <Reveal delay={0.14}>
                            <p className="mt-6 max-w-md text-base leading-relaxed text-bone/70 md:text-lg">
                                We made PLYT because most hydration is either a sugar bomb
                                or a boring sip. This is the middle — functional, clean,
                                and built for people who actually go long.
                            </p>
                        </Reveal>
                    </div>

                    <div className="md:col-span-7">
                        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                            {points.map((p, i) => {
                                const Icon = p.icon;
                                return (
                                    <Reveal key={p.title} delay={i * 0.08}>
                                        <div className="sticker-bone h-full rounded-3xl bg-bone p-6">
                                            <span className={`flex h-12 w-12 items-center justify-center rounded-2xl ${p.color} text-ink`}>
                                                <Icon className="h-6 w-6" strokeWidth={2.5} />
                                            </span>
                                            <h3 className="font-display mt-5 text-xl font-extrabold uppercase tracking-tight text-ink">
                                                {p.title}
                                            </h3>
                                            <p className="mt-2 text-sm leading-relaxed text-ink/65">
                                                {p.body}
                                            </p>
                                        </div>
                                    </Reveal>
                                );
                            })}
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default WhatsInside;

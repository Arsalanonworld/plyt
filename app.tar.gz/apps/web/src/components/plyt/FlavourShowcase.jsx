import React from 'react';
import Reveal from '@/components/Reveal';

const flavours = [
    {
        code: '01',
        name: 'CHARGE',
        flavour: 'Mango',
        color: 'orange',
        vibe: 'FIRST SPARK',
        note: 'The opener. Bright, mango-forward, fast — built for the first push when the session is just getting started.',
    },
    {
        code: '02',
        name: 'IGNITE',
        flavour: 'Lemon Mint',
        color: 'lime',
        vibe: 'STAY SHARP',
        note: 'Sharp and clean. The one you reach for when the heat is on and the game is still level.',
    },
    {
        code: '03',
        name: 'SURGE',
        flavour: 'Mixed Berry',
        color: 'purple',
        vibe: 'DEEP END',
        note: 'Deep and electric — engineered for the back half, when the session is won or lost.',
    },
    {
        code: '04',
        name: 'RELOAD',
        flavour: 'Watermelon Salt',
        color: 'pink',
        vibe: 'GO AGAIN',
        note: 'Salty and loud. Recovery that does not whisper — the reset before you go again.',
    },
];

const colorMap = {
    orange: { bg: 'bg-orange', text: 'text-orange', fg: 'text-ink' },
    lime: { bg: 'bg-lime', text: 'text-lime', fg: 'text-ink' },
    purple: { bg: 'bg-purple', text: 'text-purple', fg: 'text-bone' },
    pink: { bg: 'bg-pink', text: 'text-pink', fg: 'text-ink' },
};

const FlavourShowcase = () => {
    return (
        <section id="flavours" className="relative bg-bone">
            <div className="mx-auto max-w-6xl px-4 py-20 md:px-6 md:py-32">
                <Reveal>
                    <p className="font-tech mb-4 text-[11px] font-bold tracking-widest text-orange">
                        / THE FLAVOURS
                    </p>
                </Reveal>
                <Reveal delay={0.08}>
                    <h2 className="font-display max-w-3xl text-4xl font-extrabold uppercase leading-[0.95] tracking-tight text-ink sm:text-6xl md:text-7xl">
                        Four flavours.{' '}
                        <span className="text-outline">Pick your pulse.</span>
                    </h2>
                </Reveal>
                <Reveal delay={0.14}>
                    <p className="mt-5 max-w-xl text-base leading-relaxed text-ink/65 md:text-lg">
                        Each PLYT carries its own colour, its own vibe, its own moment in
                        the session. Same job — keep you going — different energy.
                    </p>
                </Reveal>

                <div className="mt-14 grid grid-cols-1 gap-6 sm:grid-cols-2 md:mt-20">
                    {flavours.map((f, i) => {
                        const c = colorMap[f.color];
                        const rot = i % 2 === 0 ? 'md:-rotate-1' : 'md:rotate-1';
                        return (
                            <Reveal key={f.code} delay={i * 0.08}>
                                <article className={`group relative flex h-full flex-col overflow-hidden rounded-3xl sticker-lg ${c.bg} ${rot} transition-transform duration-300 hover:rotate-0 hover:-translate-y-1`}>
                                    <div className="flex items-start justify-between p-6 md:p-8">
                                        <span className={`font-tech text-[11px] font-bold tracking-widest ${c.fg === 'text-bone' ? 'text-bone/70' : 'text-ink/70'}`}>
                                            SKU / {f.code}
                                        </span>
                                        <span className={`font-tech rounded-full border-2 ${c.fg === 'text-bone' ? 'border-bone/60 text-bone' : 'border-ink/60 text-ink'} px-3 py-1 text-[10px] font-bold tracking-widest`}>
                                            {f.vibe}
                                        </span>
                                    </div>

                                    <div className="px-6 md:px-8">
                                        <span className={`font-display block text-[28vw] font-extrabold leading-[0.8] tracking-tighter ${c.fg === 'text-bone' ? 'text-bone/15' : 'text-ink/15'} sm:text-[10rem]`}>
                                            {f.code}
                                        </span>
                                    </div>

                                    <div className="mt-auto p-6 md:p-8">
                                        <h3 className={`font-display text-3xl font-extrabold uppercase leading-none tracking-tight ${c.fg} md:text-4xl`}>
                                            {f.name}
                                        </h3>
                                        <p className={`font-tech mt-2 text-[12px] font-bold tracking-widest ${c.fg === 'text-bone' ? 'text-bone/80' : 'text-ink/80'}`}>
                                            {f.flavour.toUpperCase()}
                                        </p>
                                        <p className={`mt-4 max-w-xs text-sm leading-relaxed ${c.fg === 'text-bone' ? 'text-bone/85' : 'text-ink/75'}`}>
                                            {f.note}
                                        </p>
                                    </div>
                                </article>
                            </Reveal>
                        );
                    })}
                </div>

                <Reveal delay={0.1}>
                    <p className="font-tech mt-10 text-center text-[11px] tracking-widest text-ink/45">
                        ALL FOUR LAND WITH DROP 01 — JOIN THE WAITLIST FOR FIRST ACCESS
                    </p>
                </Reveal>
            </div>
        </section>
    );
};

export default FlavourShowcase;

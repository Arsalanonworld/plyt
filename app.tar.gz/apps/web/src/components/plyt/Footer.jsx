import React from 'react';

const Footer = () => {
    return (
        <footer className="relative bg-ink text-bone">
            <div className="mx-auto max-w-6xl px-4 pt-16 md:px-6 md:pt-20">
                <div className="grid grid-cols-2 gap-10 pb-14 md:grid-cols-4">
                    <div className="col-span-2 md:col-span-1">
                        <div className="flex items-center gap-2">
                            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-bone">
                                <span className="block h-3.5 w-3.5 rounded-full bg-orange" />
                            </span>
                            <span className="font-display text-2xl font-extrabold tracking-tight text-bone">
                                PLYT
                            </span>
                        </div>
                        <p className="font-tech mt-4 text-[10px] leading-relaxed tracking-widest text-bone/45">
                            PERFORMANCE HYDRATION
                            <br />
                            BUILT FOR THE FULL SESSION.
                        </p>
                        <div className="mt-5 flex items-center gap-1.5" aria-hidden="true">
                            <span className="h-3 w-6 rounded-full bg-orange" />
                            <span className="h-3 w-6 rounded-full bg-lime" />
                            <span className="h-3 w-6 rounded-full bg-purple" />
                            <span className="h-3 w-6 rounded-full bg-pink" />
                        </div>
                    </div>
                    <div>
                        <p className="font-tech mb-4 text-[10px] font-bold tracking-widest text-bone/40">CONTACT</p>
                        <a
                            href="mailto:hello@plyt.in"
                            className="font-tech text-[12px] font-bold tracking-widest text-bone underline-offset-4 transition-colors hover:text-orange hover:underline"
                        >
                            HELLO@PLYT.IN
                        </a>
                    </div>
                    <div>
                        <p className="font-tech mb-4 text-[10px] font-bold tracking-widest text-bone/40">FOLLOW</p>
                        <a
                            href="https://www.instagram.com/drinkplyt"
                            target="_blank"
                            rel="noreferrer"
                            className="font-tech block text-[12px] font-bold tracking-widest text-bone underline-offset-4 transition-colors hover:text-orange hover:underline"
                        >
                            INSTAGRAM — @DRINKPLYT
                        </a>
                        <a
                            href="https://x.com/drinkplyt"
                            target="_blank"
                            rel="noreferrer"
                            className="font-tech mt-3 block text-[12px] font-bold tracking-widest text-bone underline-offset-4 transition-colors hover:text-orange hover:underline"
                        >
                            X — @DRINKPLYT
                        </a>
                    </div>
                    <div>
                        <p className="font-tech mb-4 text-[10px] font-bold tracking-widest text-bone/40">STATUS</p>
                        <p className="font-tech text-[12px] font-bold tracking-widest text-bone">
                            DROP 01 — <span className="text-orange">LOADING</span>
                        </p>
                    </div>
                </div>

                <div className="font-tech flex flex-col gap-2 border-t border-white/10 py-6 text-[10px] font-bold tracking-widest text-bone/40 sm:flex-row sm:items-center sm:justify-between">
                    <span>© 2025 PLYT. ALL RIGHTS RESERVED.</span>
                    <span>PLYT.IN — MADE IN INDIA</span>
                </div>
            </div>

            <div className="pointer-events-none overflow-hidden" aria-hidden="true">
                <div className="font-display -mb-[4vw] text-center text-[26vw] font-extrabold leading-[0.8] tracking-tight text-white/[0.06]">
                    PLYT
                </div>
            </div>
        </footer>
    );
};

export default Footer;

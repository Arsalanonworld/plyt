import React from 'react';
import Reveal from '@/components/Reveal';
import { Instagram, ArrowUpRight } from 'lucide-react';

const tiles = [
    { color: 'bg-orange', fg: 'text-ink', label: 'CHARGE', tag: 'FIRST SPARK', rot: '-rotate-3' },
    { color: 'bg-lime', fg: 'text-ink', label: 'IGNITE', tag: 'STAY SHARP', rot: 'rotate-2' },
    { color: 'bg-purple', fg: 'text-bone', label: 'SURGE', tag: 'DEEP END', rot: '-rotate-2' },
    { color: 'bg-pink', fg: 'text-ink', label: 'RELOAD', tag: 'GO AGAIN', rot: 'rotate-3' },
];

const SocialSection = () => {
    return (
        <section className="relative overflow-hidden bg-bone">
            <div className="mx-auto max-w-6xl px-4 py-20 md:px-6 md:py-32">
                <div className="flex flex-col items-start justify-between gap-6 md:flex-row md:items-end">
                    <div>
                        <Reveal>
                            <p className="font-tech mb-4 text-[11px] font-bold tracking-widest text-orange">
                                / THE FEED
                            </p>
                        </Reveal>
                        <Reveal delay={0.08}>
                            <h2 className="font-display text-4xl font-extrabold uppercase leading-[0.95] tracking-tight text-ink sm:text-5xl md:text-6xl">
                                Find your flavour.{' '}
                                <span className="text-pink">Loud.</span>
                            </h2>
                        </Reveal>
                    </div>
                    <Reveal delay={0.14}>
                        <a
                            href="https://www.instagram.com/drinkplyt"
                            target="_blank"
                            rel="noreferrer"
                            className="sticker inline-flex items-center gap-3 rounded-full bg-ink px-6 py-3 font-tech text-[12px] font-bold tracking-widest text-bone transition-transform duration-200 hover:-translate-y-1 hover:translate-x-1"
                        >
                            <Instagram className="h-4 w-4" strokeWidth={2.5} />
                            @DRINKPLYT
                            <ArrowUpRight className="h-4 w-4" strokeWidth={2.5} />
                        </a>
                    </Reveal>
                </div>

                <div className="mt-12 grid grid-cols-2 gap-4 md:grid-cols-4 md:gap-6">
                    {tiles.map((t, i) => (
                        <Reveal key={t.label} delay={i * 0.08}>
                            <div className={`sticker group flex aspect-square flex-col justify-between rounded-3xl ${t.color} ${t.rot} p-5 transition-transform duration-300 hover:rotate-0 hover:-translate-y-1`}>
                                <span className={`font-tech text-[10px] font-bold tracking-widest ${t.fg === 'text-bone' ? 'text-bone/70' : 'text-ink/70'}`}>
                                    @{i + 1}
                                </span>
                                <div>
                                    <span className={`font-display block text-2xl font-extrabold uppercase leading-none tracking-tight ${t.fg} md:text-3xl`}>
                                        {t.label}
                                    </span>
                                    <span className={`font-tech mt-2 block text-[10px] font-bold tracking-widest ${t.fg === 'text-bone' ? 'text-bone/80' : 'text-ink/80'}`}>
                                        {t.tag}
                                    </span>
                                </div>
                            </div>
                        </Reveal>
                    ))}
                </div>

                <Reveal delay={0.1}>
                    <p className="font-tech mt-10 max-w-lg text-[12px] leading-relaxed tracking-widest text-ink/55">
                        WE'RE BUILDING PLYT IN THE OPEN — FOLLOW ALONG FOR DROP 01 TEASERS, FLAVOUR REVEALS, AND FIRST-LOOK ACCESS.
                    </p>
                </Reveal>
            </div>
        </section>
    );
};

export default SocialSection;

import React from 'react';

const Header = () => {
    return (
        <header className="fixed inset-x-0 top-0 z-50">
            <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 md:px-6">
                <a href="#top" className="flex items-center gap-2" aria-label="PLYT home">
                    <span className="flex h-8 w-8 items-center justify-center rounded-full bg-ink">
                        <span className="block h-3.5 w-3.5 rounded-full bg-orange" />
                    </span>
                    <span className="font-display text-2xl font-extrabold tracking-tight text-ink">
                        PLYT
                    </span>
                </a>
                <div className="flex items-center gap-3">
                    <a
                        href="https://www.instagram.com/drinkplyt"
                        target="_blank"
                        rel="noreferrer"
                        className="font-tech hidden rounded-full border-2 border-ink px-4 py-1.5 text-[11px] tracking-widest text-ink transition-colors hover:bg-ink hover:text-bone sm:block"
                    >
                        @DRINKPLYT
                    </a>
                    <a
                        href="#waitlist"
                        className="font-tech rounded-full bg-ink px-4 py-2 text-[11px] font-bold tracking-widest text-bone transition-transform duration-200 hover:-translate-y-0.5 active:scale-95"
                    >
                        JOIN THE DROP
                    </a>
                </div>
            </div>
        </header>
    );
};

export default Header;

import React from 'react';
import { motion, MotionConfig } from 'framer-motion';
import { ArrowDown, Sparkles } from 'lucide-react';

const flavours = [
    { name: 'CHARGE', color: 'bg-orange', text: 'text-ink', rot: '-rotate-6', z: 'z-30' },
    { name: 'IGNITE', color: 'bg-lime', text: 'text-ink', rot: 'rotate-3', z: 'z-20' },
    { name: 'SURGE', color: 'bg-purple', text: 'text-bone', rot: '-rotate-3', z: 'z-10' },
    { name: 'RELOAD', color: 'bg-pink', text: 'text-ink', rot: 'rotate-6', z: 'z-40' },
];

const Hero = () => {
    return (
        <MotionConfig reducedMotion="user">
            <section id="top" className="relative overflow-hidden bg-bone pt-20">
                {/* playful colour blobs in the background */}
                <div className="pointer-events-none absolute -left-20 top-32 h-72 w-72 blob-a bg-orange/30" aria-hidden="true" />
                <div className="pointer-events-none absolute -right-16 top-10 h-56 w-56 blob-b bg-lime/40" aria-hidden="true" />
                <div className="pointer-events-none absolute bottom-40 left-1/3 h-40 w-40 blob-c bg-pink/30" aria-hidden="true" />

                <div className="relative mx-auto max-w-6xl px-4 pb-10 pt-10 md:px-6 md:pt-16">
                    <div className="grid grid-cols-1 items-center gap-10 md:grid-cols-12 md:gap-6">
                        {/* left — headline + launch energy */}
                        <div className="md:col-span-7">
                            <motion.div
                                initial={{ opacity: 0, y: 12 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ duration: 0.5 }}
                                className="mb-6 flex flex-wrap items-center gap-2"
                            >
                                <span className="font-tech inline-flex items-center gap-1.5 rounded-full border-2 border-ink bg-bone px-3 py-1 text-[10px] font-bold tracking-widest text-ink">
                                    <Sparkles className="h-3 w-3" strokeWidth={2.5} />
                                    PERFORMANCE HYDRATION
                                </span>
                                <span className="font-tech inline-flex items-center gap-2 rounded-full bg-ink px-3 py-1 text-[10px] font-bold tracking-widest text-bone">
                                    <span className="relative flex h-1.5 w-1.5">
                                        <span className="absolute inline-flex h-full w-full animate-ping bg-orange opacity-70" />
                                        <span className="relative inline-flex h-1.5 w-1.5 bg-orange" />
                                    </span>
                                    DROP 01 LOADING
                                </span>
                            </motion.div>

                            <h1 className="font-display text-[15vw] font-extrabold uppercase leading-[0.88] tracking-tight text-ink sm:text-[10vw] lg:text-[7.5rem]">
                                <span className="block overflow-hidden">
                                    <motion.span
                                        initial={{ y: '110%' }}
                                        animate={{ y: '0%' }}
                                        transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1], delay: 0.1 }}
                                        className="block"
                                    >
                                        Hydration
                                    </motion.span>
                                </span>
                                <span className="block overflow-hidden">
                                    <motion.span
                                        initial={{ y: '110%' }}
                                        animate={{ y: '0%' }}
                                        transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1], delay: 0.22 }}
                                        className="block"
                                    >
                                        with a{' '}
                                        <span className="text-orange">pulse</span>.
                                    </motion.span>
                                </span>
                            </h1>

                            <motion.p
                                initial={{ opacity: 0, y: 14 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ duration: 0.5, delay: 0.4 }}
                                className="mt-6 max-w-md text-base leading-relaxed text-ink/70 md:text-lg"
                            >
                                Four flavours. One job — keep you going when the session
                                gets long. PLYT is performance hydration built for the
                                grinders, the strivers, the ones still going.
                            </motion.p>

                            <motion.div
                                initial={{ opacity: 0, y: 14 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ duration: 0.5, delay: 0.5 }}
                                className="mt-8 flex flex-col items-start gap-4 sm:flex-row sm:items-center"
                            >
                                <a
                                    href="#waitlist"
                                    className="sticker inline-flex h-14 items-center gap-3 rounded-full bg-orange px-7 font-tech text-[12px] font-bold tracking-widest text-ink transition-transform duration-200 hover:-translate-y-1 hover:translate-x-1 active:scale-95"
                                >
                                    GET EARLY ACCESS
                                    <ArrowDown className="h-4 w-4" strokeWidth={2.5} />
                                </a>
                                <a
                                    href="#flavours"
                                    className="font-tech inline-flex h-14 items-center rounded-full border-2 border-ink px-6 text-[12px] font-bold tracking-widest text-ink transition-colors hover:bg-ink hover:text-bone"
                                >
                                    MEET THE FLAVOURS
                                </a>
                            </motion.div>

                            {/* launch progress bar */}
                            <motion.div
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                transition={{ duration: 0.6, delay: 0.7 }}
                                className="mt-10 max-w-sm"
                            >
                                <div className="font-tech mb-2 flex items-center justify-between text-[10px] tracking-widest text-ink/60">
                                    <span>DROP 01 — LOADING</span>
                                    <span className="text-ink">73%</span>
                                </div>
                                <div className="h-3 w-full overflow-hidden rounded-full border-2 border-ink bg-bone">
                                    <motion.div
                                        initial={{ width: 0 }}
                                        animate={{ width: '73%' }}
                                        transition={{ duration: 1.2, delay: 0.8, ease: [0.16, 1, 0.3, 1] }}
                                        className="h-full rounded-full bg-gradient-to-r from-orange via-pink to-purple"
                                    />
                                </div>
                            </motion.div>
                        </div>

                        {/* right — stacked flavour sticker cards */}
                        <div className="md:col-span-5">
                            <div className="relative mx-auto h-[360px] w-full max-w-sm md:h-[460px]">
                                {flavours.map((f, i) => {
                                    const positions = [
                                        'left-0 top-6',
                                        'right-2 top-0',
                                        'left-6 bottom-0',
                                        'right-0 bottom-10',
                                    ];
                                    return (
                                        <motion.div
                                            key={f.name}
                                            initial={{ opacity: 0, scale: 0.5, rotate: 0 }}
                                            animate={{ opacity: 1, scale: 1 }}
                                            transition={{ duration: 0.6, delay: 0.5 + i * 0.12, ease: [0.16, 1, 0.3, 1] }}
                                            className={`absolute ${positions[i]} ${f.z} ${f.rot} animate-float-slow`}
                                            style={{ animationDelay: `${i * 0.8}s` }}
                                        >
                                            <div className={`sticker flex h-32 w-28 flex-col justify-between rounded-3xl ${f.color} p-3 md:h-36 md:w-32`}>
                                                <span className={`font-tech text-[9px] font-bold tracking-widest ${f.text}/70`}>
                                                    0{i + 1}
                                                </span>
                                                <span className={`font-display text-xl font-extrabold uppercase leading-none tracking-tight ${f.text}`}>
                                                    {f.name}
                                                </span>
                                            </div>
                                        </motion.div>
                                    );
                                })}
                                {/* centre badge */}
                                <motion.div
                                    initial={{ opacity: 0, scale: 0 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    transition={{ duration: 0.5, delay: 1.1, type: 'spring' }}
                                    className="absolute left-1/2 top-1/2 z-40 -translate-x-1/2 -translate-y-1/2"
                                >
                                    <div className="sticker flex h-20 w-20 items-center justify-center rounded-full bg-ink">
                                        <span className="font-display text-2xl font-extrabold tracking-tight text-bone">PLYT</span>
                                    </div>
                                </motion.div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* marquee ticker */}
                <div className="relative mt-4 border-y-2 border-ink bg-ink py-3">
                    <div className="flex w-max animate-marquee gap-8 whitespace-nowrap">
                        {Array.from({ length: 2 }).map((_, dup) => (
                            <div key={dup} className="flex items-center gap-8">
                                {['NO SUGAR BOMBS', 'FUNCTIONAL ELECTROLYTES', 'BUILT FOR THE FULL SESSION', 'FOUR FLAVOURS', 'MADE IN INDIA', 'DROP 01 LOADING'].map((t, i) => (
                                    <span key={i} className="font-tech flex items-center gap-8 text-[12px] font-bold tracking-widest text-bone">
                                        {t}
                                        <span className="h-1.5 w-1.5 rounded-full bg-orange" />
                                    </span>
                                ))}
                            </div>
                        ))}
                    </div>
                </div>
            </section>
        </MotionConfig>
    );
};

export default Hero;
